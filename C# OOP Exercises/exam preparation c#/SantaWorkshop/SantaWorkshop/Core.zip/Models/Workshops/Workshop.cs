﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using SantaWorkshop.Models.Dwarfs.Contracts;
using SantaWorkshop.Models.Presents;
using SantaWorkshop.Models.Presents.Contracts;
using SantaWorkshop.Models.Workshops.Contracts;

namespace SantaWorkshop.Models.Workshops
{
    public class Workshop : IWorkshop
    {
        public void Craft(IPresent present, IDwarf dwarf)
        {
            while (true)
            {
                var instrument = dwarf.Instruments.FirstOrDefault();
                if (instrument == null)
                {
                    break;
                }

                if (present.IsDone())
                {
                    break;
                }

                if (dwarf.Energy == 0)
                {
                    break;
                }

                if (instrument.IsBroken())
                {
                    dwarf.Instruments.Remove(dwarf.Instruments.ElementAt(0));
                    if (!dwarf.Instruments.Any())
                    {
                        break;
                    }
                    instrument = dwarf.Instruments.FirstOrDefault();
                }
                dwarf.Work();
                instrument.Use();
                present.GetCrafted();
            }
        }
    }
}
