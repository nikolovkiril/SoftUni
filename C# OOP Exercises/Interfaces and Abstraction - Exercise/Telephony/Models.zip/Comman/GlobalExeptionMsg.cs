﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Comman
{
    public  static class GlobalExeptionMsg
    {
        public static string WrongUrlExceptionMessage = "Invalid URL!";

        public static string WrongNumberExceptionMessage = "Invalid number!";
    }
}
