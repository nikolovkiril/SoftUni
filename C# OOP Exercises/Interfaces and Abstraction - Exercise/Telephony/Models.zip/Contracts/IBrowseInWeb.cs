﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text;

namespace Telephony.Contracts
{
    public interface IBrowseInWeb
    {
       string Url(string url);
    }
}
