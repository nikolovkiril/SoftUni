﻿using BirthdayCelebrations.Core;
using BorderControl;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BirthdayCelebrations
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }        
    }
}
