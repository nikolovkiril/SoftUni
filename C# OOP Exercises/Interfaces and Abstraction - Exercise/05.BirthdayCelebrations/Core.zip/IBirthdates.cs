﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public interface IBirthdates
    {
        string Birthdates { get; }

        string Name { get; }
    }
}
