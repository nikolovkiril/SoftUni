﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface ICheckId
    {
        string Id { get; }

        //string Model { get; }

    }
}
