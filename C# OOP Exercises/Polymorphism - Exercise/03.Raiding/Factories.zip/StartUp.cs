﻿using System;
using Raiding.Core;

namespace Raiding
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
