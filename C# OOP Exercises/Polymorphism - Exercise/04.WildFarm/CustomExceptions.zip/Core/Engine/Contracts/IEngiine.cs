﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Core.Engine.Contracts
{
    public interface IEngiine
    {
        void Run();
    }
}
