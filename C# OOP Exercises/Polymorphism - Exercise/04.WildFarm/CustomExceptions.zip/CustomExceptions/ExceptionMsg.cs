﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.CustomExceptions
{
    public static class ExceptionMsg
    {
        public static string DOESNT_EAT_MSG = "{0} does not eat {1}!";
    }
}
