﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Food
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) 
            : base(quantity)
        {

        }
    }
}
