
var firebaseConfig = {
  apiKey: "AIzaSyAVb5JLIqWsrsOUhHrzjPt3bK00Bw1Ts7c",
  authDomain: "workshop-shoes-store.firebaseapp.com",
  databaseURL: "https://workshop-shoes-store.firebaseio.com",
  projectId: "workshop-shoes-store",
  storageBucket: "workshop-shoes-store.appspot.com",
  messagingSenderId: "529079055413",
  appId: "1:529079055413:web:6c8b0f6a26de2a351bed7c"
};
firebase.initializeApp(firebaseConfig);


