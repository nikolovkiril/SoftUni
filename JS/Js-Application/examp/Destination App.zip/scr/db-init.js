var firebaseConfig = {
  apiKey: "AIzaSyBoUUtoJycU2muHbEujzIP7qc9KSy_UDTU",
  authDomain: "examp-e1968.firebaseapp.com",
  projectId: "examp-e1968",
  storageBucket: "examp-e1968.appspot.com",
  messagingSenderId: "767753356984",
  appId: "1:767753356984:web:522dc7453ea1c36821964d"
};
firebase.initializeApp(firebaseConfig);