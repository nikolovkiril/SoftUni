﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            "Data Source=.\\SQLEXPRESS;Initial Catalog=MusicHub;Integrated Security=True";
    }
}
