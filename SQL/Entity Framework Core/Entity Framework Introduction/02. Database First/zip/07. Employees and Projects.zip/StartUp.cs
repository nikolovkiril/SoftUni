﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            var print = GetEmployeesInPeriod(db);
            Console.WriteLine(print);


        }
        /* public static string GetEmployeesFullInformation(SoftUniContext context)
         {
             var employees = context.Employees
                 .OrderBy(x => x.EmployeeId)
                 .ToList();

             var sb = new StringBuilder();

             foreach (var employee in employees)
             {
                 sb.AppendLine($"{employee.FirstName} {employee.LastName} " +
                     $"{employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
             }
             var result = sb.ToString().TrimEnd();
             return result ; 
         }*/

        /* public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
         {
             var employeeWithSalaryOver = context.Employees
                 .OrderBy(x => x.FirstName)
                 .Where(x => x.Salary > 50_000)
                 .ToList();

             var sb = new StringBuilder();

             foreach (var employee in employeeWithSalaryOver)
             {
                 sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
             }

             var result = sb.ToString().TrimEnd();

             return result;
         }*/

        /*public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employeeWithSalaryOver = context.Employees
                .Where(x => x.Department.Name == "Research and Development")
                .OrderBy(x => x.Salary)
                .ThenByDescending(x => x.FirstName)
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.Salary,
                    Department = x.Department.Name,
                })
                 .ToList();


            var sb = new StringBuilder();

            foreach (var employee in employeeWithSalaryOver)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from {employee.Department} - ${employee.Salary:F2}");
            }

            var result = sb.ToString().Trim();

            return result;
        }*/

        /*public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            Address newAdress = new Address()
            {
                AddressText = "Vitoshka 15",
                TownId = 4
            };
            context.Addresses.Add(newAdress);

            var empoyee = context.Employees.First(x => x.LastName == "Nakov");
            empoyee.Address = newAdress;

            context.SaveChanges();

            var adresses = context.Employees
                .OrderByDescending(x => x.AddressId)
                .Take(10)
                .Select(x => x.Address.AddressText)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var adressText in adresses)
            {
                sb.AppendLine(adressText);
            }
            var result = sb.ToString().TrimEnd();
            return result;
        }*/

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees
                 .Where(e => e.EmployeesProjects.Any(ep => ep.Project.StartDate.Year >= 2001 && ep.Project.StartDate.Year <= 2003))
                 .Take(10)
                 .Select(e => new
                 {
                     e.FirstName,
                     e.LastName,
                     ManagerFirstName = e.Manager.FirstName,
                     ManagerLastName = e.Manager.LastName,
                     Projects = e.EmployeesProjects
                     .Select(ep => new
                     {
                         ProjectName = ep.Project.Name,
                         StartDate = ep.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture),
                         EndDate = ep.Project.EndDate.HasValue ?
                         ep.Project.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture) : "not finished"
                     })
                     .ToList()
                 })
                 .ToList();

            foreach (var e in employees)
            {
                sb.AppendLine($"{e.FirstName} {e.LastName} - Manager: {e.ManagerFirstName} {e.ManagerLastName}");

                foreach (var p in e.Projects)
                {
                    sb.AppendLine($"--{p.ProjectName} - {p.StartDate} - {p.EndDate}");
                }
            }

            var result = sb.ToString().TrimEnd();
            return result;
        }
    }
}
