﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            var print = GetEmployeesFromResearchAndDevelopment(db);
            Console.WriteLine(print);


        }
        /* public static string GetEmployeesFullInformation(SoftUniContext context)
         {
             var employees = context.Employees
                 .OrderBy(x => x.EmployeeId)
                 .ToList();

             var sb = new StringBuilder();

             foreach (var employee in employees)
             {
                 sb.AppendLine($"{employee.FirstName} {employee.LastName} " +
                     $"{employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
             }
             var result = sb.ToString().TrimEnd();
             return result ; 
         }*/

        /* public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
         {
             var employeeWithSalaryOver = context.Employees
                 .OrderBy(x => x.FirstName)
                 .Where(x => x.Salary > 50_000)
                 .ToList();

             var sb = new StringBuilder();

             foreach (var employee in employeeWithSalaryOver)
             {
                 sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
             }

             var result = sb.ToString().TrimEnd();

             return result;
         }*/

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employeeWithSalaryOver = context.Employees
                .Where(x => x.Department.Name == "Research and Development")
                .OrderBy(x => x.Salary)
                .ThenByDescending(x => x.FirstName)
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.Salary,
                    Department = x.Department.Name,
                })
                 .ToList();


            var sb = new StringBuilder();

            foreach (var employee in employeeWithSalaryOver)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from {employee.Department} - ${employee.Salary:F2}");
            }

            var result = sb.ToString().Trim();

            return result;
        }
    }
}
