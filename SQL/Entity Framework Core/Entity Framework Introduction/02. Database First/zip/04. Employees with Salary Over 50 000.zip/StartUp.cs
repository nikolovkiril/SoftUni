﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
       public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            var print = GetEmployeesWithSalaryOver50000(db);
            Console.WriteLine(print);
            

        }
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employeeWithSalaryOver = context.Employees
                .OrderBy(x => x.FirstName)
                .Where(x => x.Salary > 50000)
                .ToList();
            var sb = new StringBuilder();
            foreach (var employee in employeeWithSalaryOver)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }
            var result = sb.ToString().TrimEnd(); 
            return result;
        }
    }
}
