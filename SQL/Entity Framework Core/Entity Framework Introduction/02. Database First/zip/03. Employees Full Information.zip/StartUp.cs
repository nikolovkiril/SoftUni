﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
       public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            var print = GetEmployeesFullInformation(db);
            Console.WriteLine(print);
            

        }
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                .OrderBy(x => x.EmployeeId)
                .ToList();

            var sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
            }
            var result = sb.ToString().TrimEnd();
            return result ; 
        }
    }
}
